package Business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {
	List<Order> orders = new ArrayList<Order>();

	/**
	 * @see OrdersBusinessInterface#test()
	 */
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("This is a testtttt");
	}
	
    /**
     * Default constructor. 
     */
    public OrdersBusinessService() {
		// TODO Auto-generated constructor stub
    	orders.add(new Order("0001","hand sanitizer slime", 20.3f, 30));
		orders.add(new Order("0002","mermaid tail", 35.3f, 30));
		orders.add(new Order("0003","movie prop money", 6.7f, 30));
		orders.add(new Order("0004","pet paint", 20.3f, 30));
		orders.add(new Order("0005","Drinking horn", 13.3f, 30));
		
    }


	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		// TODO Auto-generated method stub
		this.orders = orders;
	}

	@Override
	public void onSubmit() {
		// TODO Auto-generated method stub
		
	}

}

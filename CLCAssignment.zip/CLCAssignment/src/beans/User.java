package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped

public class User 
{
//	private String firstName;
//	private String lastName;
//	private String email;
//	private String password;
//	private String homeAddress;
//	private String phoneNumber;
	
	
	
	@NotNull(message = "Please Enter a First Name")
	@Size(min=5, max=15,  message = "You must enter a first name with atleast 2 chars and at most 20")
String firstName = "";
	
	@NotNull(message = "Please Enter a Last Name")
	@Size(min=5, max=15,  message = "You must enter a last name with atleast 2 chars and at most 20")
String lastName = "";


	@NotNull(message = "Please Enter an email")
	@Size(min=5, max=30,  message = "You must enter an email address")
String email = "";

	@NotNull(message = "Please Enter a password")
	@Size(min=5, max=15,  message = "You must enter a password with atleast 2 chars and at most 20")
String password = "";

	@NotNull(message = "Please Enter your phone number")
	@Size(min=5, max=15,  message = "You must enter a last name with atleast 2 chars and at most 20")
String phoneNumber = "";

	@NotNull(message = "Please enter your address")
	@Size(min=5, max=30,  message = "You must enter a last name with atleast 2 chars and at most 20")
String homeAddress = "";

	
	
public User()
{
	this.firstName = "patrick";
	this.lastName = "ulmer";
	this.email = "laxulmer@gmail.com";
	this.password = "password";
	this.phoneNumber = "8014140871";
	this.homeAddress = "address";
	
	
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String gethomeAddress() {
	return homeAddress;
}

public void setAddress(String homeAddress) {
	this.homeAddress = homeAddress;
}

public String getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}

	
}

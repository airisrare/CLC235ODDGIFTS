package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import Business.OrdersBusinessInterface;
import beans.User;

@ManagedBean
@ViewScoped
public class FormController 
{
	@Inject
	OrdersBusinessInterface services;
	
	public String onSubmit(User user) {
		

		System.out.println("Submit Clicked");
		System.out.println("FirstName" + user.getFirstName());
		System.out.println("LastName" + user.getLastName());
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		return "Response.xhtml";
	}
	
	
	
	public String registerPage()
	{

		return "Register.xhtml";
	}
	
	public String returnToHome() {
		
		return "Register.xhtml";
	}
	
	
	
	public String registerSuccess()
	{
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);

		System.out.println("FirstName" + user.getFirstName());
		System.out.println("LastName" + user.getLastName());
		System.out.println("Email" + user.getEmail());
		System.out.println("Password" + user.getPassword());
		System.out.println("Address" + user.gethomeAddress());
		System.out.println("PhoneNumber" + user.getPhoneNumber());
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "RegisterSuccess.xhtml";
	}
	
	
	
	
	public OrdersBusinessInterface getService() {
		return services;
		
	}

}
